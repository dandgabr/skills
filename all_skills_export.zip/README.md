# Antigravity Global Skills Bundle

Este repositório contém uma estrutura exportável de **42 habilidades (skills)**, abrangendo Engenharia de Software, Padrões de Projeto (Design Patterns do GoF), Metodologias Ágeis, Garantia de Qualidade (QA) e Cibersegurança.

A estrutura é 100% modular, compatível com a CLI do Antigravity (AGY), IDEs de desenvolvimento e ferramentas de documentação (Obsidian, Logseq, GitBook, etc.).

## 📊 Grafo de Relações entre as Skills (Mermaid)

```mermaid
graph TD
  appsec-owasp-asvs["appsec-owasp-asvs"]
  backend-developer["backend-developer"]
  devsecops-engineer["devsecops-engineer"]
  documentation-designer["documentation-designer"]
  dp-abstract-factory["dp-abstract-factory"]
  dp-adapter["dp-adapter"]
  dp-bridge["dp-bridge"]
  dp-builder["dp-builder"]
  dp-chain-of-responsibility["dp-chain-of-responsibility"]
  dp-command["dp-command"]
  dp-composite["dp-composite"]
  dp-decorator["dp-decorator"]
  dp-facade["dp-facade"]
  dp-factory-method["dp-factory-method"]
  dp-flyweight["dp-flyweight"]
  dp-iterator["dp-iterator"]
  dp-mediator["dp-mediator"]
  dp-memento["dp-memento"]
  dp-observer["dp-observer"]
  dp-prototype["dp-prototype"]
  dp-proxy["dp-proxy"]
  dp-singleton["dp-singleton"]
  dp-state["dp-state"]
  dp-strategy["dp-strategy"]
  dp-template-method["dp-template-method"]
  dp-visitor["dp-visitor"]
  frontend-developer["frontend-developer"]
  pentester-owasp-wstg["pentester-owasp-wstg"]
  product-owner["product-owner"]
  qa-engineer["qa-engineer"]
  scrum-master["scrum-master"]
  secops-incident-responder["secops-incident-responder"]
  security-architect-sabsa["security-architect-sabsa"]
  security-grc-compliance["security-grc-compliance"]
  security-manager-samm["security-manager-samm"]
  software-architect["software-architect"]
  tech-testing["tech-testing"]
  tech-typescript["tech-typescript"]
  tech-vue["tech-vue"]
  template-skill["template-skill"]
  threat-modeler["threat-modeler"]
  ui-ux-designer["ui-ux-designer"]
  appsec-owasp-asvs --> devsecops-engineer
  appsec-owasp-asvs --> pentester-owasp-wstg
  appsec-owasp-asvs --> secops-incident-responder
  appsec-owasp-asvs --> security-architect-sabsa
  appsec-owasp-asvs --> security-grc-compliance
  appsec-owasp-asvs --> threat-modeler
  backend-developer --> appsec-owasp-asvs
  backend-developer --> frontend-developer
  backend-developer --> product-owner
  backend-developer --> qa-engineer
  backend-developer --> security-architect-sabsa
  backend-developer --> software-architect
  backend-developer --> tech-testing
  backend-developer --> tech-typescript
  devsecops-engineer --> appsec-owasp-asvs
  devsecops-engineer --> pentester-owasp-wstg
  devsecops-engineer --> security-architect-sabsa
  documentation-designer --> dp-factory-method
  documentation-designer --> software-architect
  frontend-developer --> appsec-owasp-asvs
  frontend-developer --> backend-developer
  frontend-developer --> qa-engineer
  frontend-developer --> tech-testing
  frontend-developer --> tech-typescript
  frontend-developer --> tech-vue
  frontend-developer --> ui-ux-designer
  pentester-owasp-wstg --> appsec-owasp-asvs
  pentester-owasp-wstg --> secops-incident-responder
  pentester-owasp-wstg --> security-grc-compliance
  pentester-owasp-wstg --> threat-modeler
  product-owner --> backend-developer
  product-owner --> frontend-developer
  product-owner --> qa-engineer
  product-owner --> scrum-master
  product-owner --> security-grc-compliance
  product-owner --> ui-ux-designer
  qa-engineer --> backend-developer
  qa-engineer --> frontend-developer
  qa-engineer --> pentester-owasp-wstg
  qa-engineer --> product-owner
  qa-engineer --> scrum-master
  qa-engineer --> tech-testing
  scrum-master --> devsecops-engineer
  scrum-master --> product-owner
  scrum-master --> security-manager-samm
  secops-incident-responder --> appsec-owasp-asvs
  secops-incident-responder --> pentester-owasp-wstg
  secops-incident-responder --> security-architect-sabsa
  security-architect-sabsa --> appsec-owasp-asvs
  security-architect-sabsa --> devsecops-engineer
  security-architect-sabsa --> pentester-owasp-wstg
  security-architect-sabsa --> secops-incident-responder
  security-architect-sabsa --> security-grc-compliance
  security-architect-sabsa --> security-manager-samm
  security-architect-sabsa --> threat-modeler
  security-grc-compliance --> appsec-owasp-asvs
  security-grc-compliance --> security-architect-sabsa
  security-grc-compliance --> security-manager-samm
  security-manager-samm --> appsec-owasp-asvs
  security-manager-samm --> devsecops-engineer
  security-manager-samm --> pentester-owasp-wstg
  security-manager-samm --> secops-incident-responder
  security-manager-samm --> security-architect-sabsa
  security-manager-samm --> security-grc-compliance
  security-manager-samm --> threat-modeler
  software-architect --> dp-abstract-factory
  software-architect --> dp-adapter
  software-architect --> dp-bridge
  software-architect --> dp-builder
  software-architect --> dp-chain-of-responsibility
  software-architect --> dp-command
  software-architect --> dp-composite
  software-architect --> dp-decorator
  software-architect --> dp-facade
  software-architect --> dp-factory-method
  software-architect --> dp-flyweight
  software-architect --> dp-iterator
  software-architect --> dp-mediator
  software-architect --> dp-memento
  software-architect --> dp-observer
  software-architect --> dp-prototype
  software-architect --> dp-proxy
  software-architect --> dp-singleton
  software-architect --> dp-state
  software-architect --> dp-strategy
  software-architect --> dp-template-method
  software-architect --> dp-visitor
  tech-testing --> backend-developer
  tech-testing --> frontend-developer
  tech-testing --> qa-engineer
  tech-typescript --> backend-developer
  tech-typescript --> frontend-developer
  tech-vue --> frontend-developer
  tech-vue --> tech-typescript
  threat-modeler --> appsec-owasp-asvs
  threat-modeler --> pentester-owasp-wstg
  threat-modeler --> security-architect-sabsa
  ui-ux-designer --> frontend-developer
  ui-ux-designer --> product-owner
  ui-ux-designer --> qa-engineer
```

## 📂 Estrutura de Arquivos do Pacote

```text
skills_bundle/
├── AGENTS.md            # Regras gerais de estilo e comportamento do projeto
├── skills.json          # Manifesto de registro de caminhos de customização
├── manifest.json        # Metadados estruturados das skills e suas dependências
├── README.md            # Esta documentação de referência
└── skills/              # Pasta principal contendo todas as skills
    └── [nome-da-skill]/ # Diretório de cada skill individual
        ├── SKILL.md     # Instruções em Markdown (com frontmatter YAML)
        ├── examples/    # Pasta de exemplos
        ├── references/  # Documentação de referência
        ├── resources/   # Recursos de suporte
        └── scripts/     # Scripts de automação associados
```

## 🛠️ Habilidades Incluídas no Pacote

A tabela abaixo lista todas as habilidades presentes neste pacote:

| ID da Skill | Nome da Skill | Descrição |
|-------------|---------------|-----------|
| `appsec-owasp-asvs` | **appsec-owasp-asvs** | Atua como Especialista em Application Security (AppSec) baseado no OWASP ASVS v5.0.0 integrado ao NIST SSDF, CWE e CERT Secure Coding, aplicando controles de código seguro em design e implementação. |
| `backend-developer` | **backend-developer** | Atua como Desenvolvedor Backend sênior, projetando APIs robustas, integrando bancos de dados eficientes, aplicando concorrência segura, otimizando performance e criando testes de integração robustos. |
| `devsecops-engineer` | **devsecops-engineer** | Atua como Engenheiro de DevSecOps, automatizando verificações de segurança no pipeline de CI/CD (SAST, DAST, SCA), gerenciando secrets de forma segura e garantindo a segurança em Cloud e Containers. |
| `documentation-designer` | **documentation-designer** | Auxilia na elaboração de documentação técnica rica e no desenho de diagramas visuais e fluxogramas utilizando a sintaxe do Mermaid.js. |
| `dp-abstract-factory` | **dp-abstract-factory** | Padrão de Projeto Criacional: Permite produzir famílias de objetos relacionados ou dependentes sem especificar suas classes concretas. |
| `dp-adapter` | **dp-adapter** | Padrão de Projeto Estrutural: Permite que objetos com interfaces incompatíveis colaborem entre si. |
| `dp-bridge` | **dp-bridge** | Padrão de Projeto Estrutural: Divide uma classe grande ou um conjunto de classes intimamente ligadas em duas hierarquias separadas — abstração e implementação — que podem ser desenvolvidas independentemente. |
| `dp-builder` | **dp-builder** | Padrão de Projeto Criacional: Permite construir objetos complexos passo a passo. Permite produzir diferentes tipos e representações de um objeto usando o mesmo código de construção. |
| `dp-chain-of-responsibility` | **dp-chain-of-responsibility** | Padrão de Projeto Comportamental: Permite passar requisições por uma corrente de manipuladores. Ao receber uma requisição, cada manipulador decide se processa a requisição ou a passa para o próximo manipulador. |
| `dp-command` | **dp-command** | Padrão de Projeto Comportamental: Transforma uma solicitação em um objeto independente que contém toda a informação sobre a solicitação, permitindo parametrizar, enfileirar ou desfazer operações. |
| `dp-composite` | **dp-composite** | Padrão de Projeto Estrutural: Permite compor objetos em estruturas de árvore e trabalhar com essas estruturas como se fossem objetos individuais. |
| `dp-decorator` | **dp-decorator** | Padrão de Projeto Estrutural: Permite acoplar novos comportamentos a objetos ao colocá-los dentro de invólucros (wrappers) de objetos reais. |
| `dp-facade` | **dp-facade** | Padrão de Projeto Estrutural: Fornece uma interface simplificada para uma biblioteca, um framework, ou qualquer outro conjunto complexo de classes. |
| `dp-factory-method` | **dp-factory-method** | Padrão de Projeto Criacional: Fornece uma interface para criar objetos em uma superclasse, mas permite que as subclasses alterem o tipo de objetos que serão criados. |
| `dp-flyweight` | **dp-flyweight** | Padrão de Projeto Estrutural: Permite ajustar mais objetos na quantidade disponível de RAM ao compartilhar partes comuns de estado entre múltiplos objetos em vez de manter todos os dados em cada objeto. |
| `dp-iterator` | **dp-iterator** | Padrão de Projeto Comportamental: Permite percorrer elementos de uma coleção sem expor sua representação subjacente (lista, pilha, árvore, etc.). |
| `dp-mediator` | **dp-mediator** | Padrão de Projeto Comportamental: Reduz as dependências caóticas entre objetos. Restringe comunicações diretas entre objetos e os força a colaborar apenas através de um objeto mediador. |
| `dp-memento` | **dp-memento** | Padrão de Projeto Comportamental: Permite salvar e restaurar o estado anterior de um objeto sem revelar os detalhes de sua implementação. |
| `dp-observer` | **dp-observer** | Padrão de Projeto Comportamental: Permite definir um mecanismo de assinatura para notificar múltiplos objetos sobre quaisquer eventos que aconteçam com o objeto que eles estão observando. |
| `dp-prototype` | **dp-prototype** | Padrão de Projeto Criacional: Permite copiar objetos existentes sem tornar seu código dependente de suas classes. |
| `dp-proxy` | **dp-proxy** | Padrão de Projeto Estrutural: Fornece um substituto ou um espaço reservado para outro objeto. Um proxy controla o acesso ao objeto original, permitindo fazer algo antes ou depois que a requisição chegue a ele. |
| `dp-singleton` | **dp-singleton** | Padrão de Projeto Criacional: Garante que uma classe tenha apenas uma instância, enquanto provê um ponto de acesso global para essa instância. |
| `dp-state` | **dp-state** | Padrão de Projeto Comportamental: Permite que um objeto altere seu comportamento quando seu estado interno muda. O objeto parecerá ter mudado de classe. |
| `dp-strategy` | **dp-strategy** | Padrão de Projeto Comportamental: Define uma família de algoritmos, coloca cada um deles em uma classe separada, e faz seus objetos intercambiáveis. |
| `dp-template-method` | **dp-template-method** | Padrão de Projeto Comportamental: Define o esqueleto de um algoritmo na superclasse mas deixa as subclasses sobrescreverem etapas específicas do algoritmo sem modificar sua estrutura. |
| `dp-visitor` | **dp-visitor** | Padrão de Projeto Comportamental: Permite separar algoritmos dos objetos nos quais eles operam. |
| `frontend-developer` | **frontend-developer** | Atua como Desenvolvedor Frontend sênior, criando interfaces ricas, componentização avançada, gerenciamento de estado global eficiente, otimização de Core Web Vitals e conformidade com acessibilidade (WCAG). |
| `pentester-owasp-wstg` | **pentester-owasp-wstg** | Atua como Pentester Ético e Especialista em Testes de Invasão sênior estruturando auditorias sob o framework OWASP WSTG v4.2, correlacionando-as com técnicas MITRE ATT&CK. |
| `product-owner` | **product-owner** | Atua como Product Owner (PO), refinando histórias de usuários com critérios de aceitação BDD (Cucumber), gerenciando o Product Backlog e priorizando entregas com foco em valor de negócio (ROI). |
| `qa-engineer` | **qa-engineer** | Atua como Engenheiro de QA (Quality Assurance), elaborando estratégias de testes de software, automatizando testes E2E e de APIs, validando regressões e gerando relatórios de defeitos. |
| `scrum-master` | **scrum-master** | Atua como Scrum Master e Agile Coach, facilitando cerimônias ágeis (Planning, Review, Retrospective, Dailies), eliminando impedimentos, gerenciando conflitos e monitorando métricas de produtividade (Velocity, Burndown). |
| `secops-incident-responder` | **secops-incident-responder** | Atua como Analista de SecOps e Resposta a Incidentes, estruturando playbooks de resposta a ataques (NIST SP 800-61), monitoramento operacional (SIEM), hardening de ambientes de produção e planos de Disaster Recovery. |
| `security-architect-sabsa` | **security-architect-sabsa** | Atua como Arquiteto de Segurança de Sistemas usando o framework SABSA alinhado ao TOGAF e NIST CSF, traduzindo objetivos de negócios em controles de segurança e modelando zonas de confiança Zero Trust. |
| `security-grc-compliance` | **security-grc-compliance** | Atua como Analista de Governança, Riscos e Conformidade (GRC), estruturando políticas de segurança, alinhando frameworks (ISO 27001, PCI-DSS, LGPD/GDPR) e medindo a eficácia de segurança com métricas organizacionais. |
| `security-manager-samm` | **security-manager-samm** | Atua como Gestor de Segurança usando o framework OWASP SAMM alinhado ao BSIMM e CIS Controls para governar, avaliar e elevar a maturidade de segurança do SDLC, gerindo regras e criando novas skills. |
| `software-architect` | **software-architect** | Atua como Arquiteto de Software aplicando engenharia de baixo nível, princípios SOLID, DDD, decisões de topologia de sistemas, testabilidade e orquestração de Design Patterns. |
| `tech-testing` | **tech-testing** | Fornece diretrizes e boas práticas para testes de software robustos, cobrindo TDD, Pirâmide de Testes, Unitários, Integração e E2E, além de ferramentas como Vitest, Jest e Playwright. |
| `tech-typescript` | **tech-typescript** | Fornece padrões de engenharia de software seguro e robusto usando TypeScript, cobrindo generics, tipos avançados, segurança estrita de compilador e mapeamento defensivo de dados. |
| `tech-vue` | **tech-vue** | Fornece padrões de desenvolvimento modular e de alta performance usando o ecossistema Vue 3, cobrindo Composition API, TypeScript, Pinia, Vue Router e otimizações de reatividade. |
| `template-skill` | **template-skill** | Um template básico que demonstra como estruturar uma habilidade (skill) personalizada para agentes de IA. |
| `threat-modeler` | **threat-modeler** | Atua como Especialista em Modelagem de Ameaças (Threat Modeling), utilizando frameworks como STRIDE, PASTA e LINDDUN para antecipar ataques, identificar riscos e especificar requisitos de segurança. |
| `ui-ux-designer` | **ui-ux-designer** | Atua como Designer UI/UX, executando pesquisas com usuários, fluxos lógicos, wireframes, protótipos de alta fidelidade baseados em Design Systems e processos consistentes de Design Handover. |

## 🚀 Como Importar e Usar

### 1. Na CLI do Antigravity ou Assistentes Compatíveis
Basta extrair o arquivo ZIP no diretório desejado.
Se você deseja que o assistente carregue estas habilidades globalmente ou no seu projeto atual:
- Adicione o caminho da pasta extraída ou da subpasta `skills/` no seu arquivo `skills.json` (seja global ou local do projeto).
- O arquivo `skills.json` incluído na raiz deste pacote já está configurado para ler todas as skills presentes na pasta `skills/`.

### 2. No Obsidian ou Logseq
- Extraia o ZIP e abra a pasta extraída como um novo **Vault**.
- Graças aos links relativos padronizados no formato `../[outra-skill]/SKILL.md`, todos os links funcionarão perfeitamente para navegação visual e análise do grafo de notas.
